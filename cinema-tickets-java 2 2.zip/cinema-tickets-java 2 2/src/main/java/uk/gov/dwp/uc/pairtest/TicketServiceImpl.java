package uk.gov.dwp.uc.pairtest;

import thirdparty.paymentgateway.TicketPaymentService;
import thirdparty.paymentgateway.TicketPaymentServiceImpl;
import thirdparty.seatbooking.SeatReservationService;
import thirdparty.seatbooking.SeatReservationServiceImpl;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;
import uk.gov.dwp.uc.pairtest.exception.InvalidPurchaseException;

import java.util.Arrays;
import java.util.Map;

public class TicketServiceImpl implements TicketService {
    /**
     * Should only have private methods other than the one below.
     */

    private static final int MAX_TICKETS_AT_ONCE = 20;
    private static final Map<TicketTypeRequest.Type, Integer> ticketPrices = Map.of(
            TicketTypeRequest.Type.INFANT, 0,
            TicketTypeRequest.Type.CHILD, 10,
            TicketTypeRequest.Type.ADULT, 20
    );

    @Override
    public void purchaseTickets(Long accountId, TicketTypeRequest... ticketTypeRequests) {
        if (accountId <= 0 || ticketTypeRequests == null) {
            throw new IllegalArgumentException("Invalid input parameters");
        }

        int totalQuantity = 0;
        int totalPrice = 0;
        int adultTicketCount = 0;

        for (TicketTypeRequest request : ticketTypeRequests) {
            TicketTypeRequest.Type ticketType = request.getTicketType();
            int quantity = request.getNoOfTickets();

            if (quantity <= 0) {
                throw new IllegalArgumentException("Invalid ticket quantity");
            }

            if (ticketType == TicketTypeRequest.Type.ADULT) {
                adultTicketCount += quantity;
                if (adultTicketCount > MAX_TICKETS_AT_ONCE) {
                    throw new IllegalArgumentException("Exceeds maximum tickets for adults");
                }
            }

            totalQuantity += quantity;
            totalPrice += ticketPrices.get(ticketType) * quantity;
        }

        if (totalQuantity == 0 || totalQuantity > MAX_TICKETS_AT_ONCE) {
            throw new IllegalArgumentException("Invalid total ticket quantity");
        }

        if (adultTicketCount == 0) {
            throw new IllegalArgumentException("Adult ticket required for Child or Infant tickets");
        }

        SeatReservationService seatReservationService = new SeatReservationServiceImpl();
        seatReservationService.reserveSeat(accountId, totalQuantity);
        TicketPaymentService paymentService = new TicketPaymentServiceImpl();
        paymentService.makePayment(accountId, totalPrice);
    }


}
