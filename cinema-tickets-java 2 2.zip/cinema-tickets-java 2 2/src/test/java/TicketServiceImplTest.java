import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import uk.gov.dwp.uc.pairtest.TicketServiceImpl;
import uk.gov.dwp.uc.pairtest.domain.TicketTypeRequest;

import static org.junit.jupiter.api.Assertions.assertThrows;

public class TicketServiceImplTest {

    private TicketServiceImpl ticketService;

    private static final int MAX_TICKETS_AT_ONCE = 20;

    @BeforeEach
    public void setUp() {
        ticketService = new TicketServiceImpl();
    }

    @Test
    public void testPurchaseTickets_ValidPurchase() {
        long accountId = 123;
        TicketTypeRequest infantTicket = new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 2);
        TicketTypeRequest childTicket = new TicketTypeRequest(TicketTypeRequest.Type.CHILD, 3);
        TicketTypeRequest adultTicket = new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 4);

        ticketService.purchaseTickets(accountId, infantTicket, childTicket, adultTicket);

    }

    @Test
    public void testPurchaseTickets_InvalidInputParameters() {
        assertThrows(IllegalArgumentException.class, () -> ticketService.purchaseTickets(0L, new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 1)));

        assertThrows(IllegalArgumentException.class, () -> ticketService.purchaseTickets(123L, null));
    }

    @Test
    public void testPurchaseTickets_InvalidTicketQuantity() {
        assertThrows(IllegalArgumentException.class, () -> ticketService.purchaseTickets(123L, new TicketTypeRequest(TicketTypeRequest.Type.ADULT, 0)));

        assertThrows(IllegalArgumentException.class, () -> ticketService.purchaseTickets(123L, new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 1)));
    }

    @Test
    public void testPurchaseTickets_ExceedsMaxAdultTickets() {
        assertThrows(IllegalArgumentException.class, () -> {
            ticketService.purchaseTickets(123L,
                new TicketTypeRequest(TicketTypeRequest.Type.ADULT, MAX_TICKETS_AT_ONCE + 1));
        });
    }

    @Test
    public void testPurchaseTickets_InvalidTotalQuantity() {
        assertThrows(IllegalArgumentException.class, () -> ticketService.purchaseTickets(123L,
                new TicketTypeRequest(TicketTypeRequest.Type.CHILD, 10),
                new TicketTypeRequest(TicketTypeRequest.Type.INFANT, 0)));
    }
}
